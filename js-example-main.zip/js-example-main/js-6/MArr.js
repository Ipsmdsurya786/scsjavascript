let arr = [[1,2,3,4,6],[1,2,3]]
for(let i=0;i<2;i++){
    for(let j=0;j<3;j++){
        console.log(arr[i][j])
    }
    console.log("Next Row")
}
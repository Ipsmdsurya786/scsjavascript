num=51
console.log(num>0 && num<10)
console.log(num>0 || num<10)
console.log(!(num>0 || num<10))
console.log("1"+2)
console.log(true+2)
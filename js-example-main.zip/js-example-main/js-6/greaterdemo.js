let a=5,b=20,c=30;
if(a>b)
{
    if(a>c){
        console.log(a)
    }
    else{
        console.assert.log(c)
    }
}
else{
    if(b>c){
        console.log(b)
    }
    else{
        console.log(c)
    }
}
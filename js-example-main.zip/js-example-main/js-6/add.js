let a=10
a=100
let c = a+b
console.log('result is ',c)
let num=6
switch(num%2){  //
    case 0:
        console.log('even')
        break
    default:
        console.log('odd')
        break
}
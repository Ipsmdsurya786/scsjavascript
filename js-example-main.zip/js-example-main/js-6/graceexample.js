let mark=52
if(mark>=28 && mark<33){
    console.log('grace is ',33-mark)
    mark = mark+(33-mark)
    
}

console.log('total mark is ',mark)
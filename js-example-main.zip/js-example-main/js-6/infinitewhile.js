while(true){
    console.log('welcome in JS')
}
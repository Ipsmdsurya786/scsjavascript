let num=50
var res=''
if(num%2==0){
    res= 'even'
}
else{
   res='odd'
}
console.log(res)
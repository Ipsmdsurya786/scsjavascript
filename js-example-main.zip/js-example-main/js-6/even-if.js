let num=50
var res="odd"
if(num%2==0){
    res = "even"
}
console.log(res)
let sum=0
let i=1;
for(;i<=9;)
{
   sum =sum+i; // sum=10
   i++;
}
console.log(sum)
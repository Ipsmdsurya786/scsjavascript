let salary=15000
if(salary<10000){
    salary+=500
}
console.log(salary)
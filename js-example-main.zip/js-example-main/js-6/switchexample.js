let ch='b'
switch(ch){
    case 'a':
    case 'e':
    case 'i':
    case 'o':
    case 'u':
    console.log('Vowel')
    break
    default:
    console.log('Consonent')
    break
}

let i=1;
while(i<=10){
    if(i<=5){
        console.log(i)
    }
    else
    {
        console.log(11-i)
    }
    
    i++;
}
let age_person1=25
let age_person2=39
let result = age_person1>age_person2? "person1 age is greater":" person2 age is greater"
console.log(result)
a=5
b=--a + a-- + ++a + a++
//16   4   4      4     4 5
console.log("a="+a + "b=" +b)
let a=10,b=2,c=30;
if(a>b && a>c){
    console.log(a)
}
else if(b>c){
    console.log(b)
}
else
{
    console.log(c)
}

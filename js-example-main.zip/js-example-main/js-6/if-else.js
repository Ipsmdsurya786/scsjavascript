let salary=8000
if(salary<10000){
    salary+=500
}
else{
    salary+=1000
  
}
console.log(salary)
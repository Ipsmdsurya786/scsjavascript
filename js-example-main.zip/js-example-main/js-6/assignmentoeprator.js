let a=5
a+=5
a-=3
a*=13
a/=3

console.log(a)
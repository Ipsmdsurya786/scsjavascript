const a=10;
a=1; 
{
    const a=100;
    a=5;////not possible
    console.log('value is ',a)
}
console.log(a)

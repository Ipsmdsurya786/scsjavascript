let a=30,b=10;
let res= (parseInt(a/b)==0)?" b is greater":"a is greater "
console.log(res)
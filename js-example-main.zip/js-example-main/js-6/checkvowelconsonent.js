let ch='b'
let res=''
if(ch=='a'){
  res = 'Vowel'
}
else if(ch=='e'){
    res = 'Vowel'
}
else if(ch=='i')
{
    res = "Vowel"
}
else if(ch=='o')
{
    res = "Vowel"
}
else if(ch=='u')
{
    res = "Vowel"
}
else
{
    res = "consonent"
}
console.log(res)
let num=50
let res = (num>0 && num<10)? "single digit":"above single digit"
console.log(res)
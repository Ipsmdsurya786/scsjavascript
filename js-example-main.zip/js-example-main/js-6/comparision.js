a=10 //integer
b="10" //string
console.log(a==b)
console.log(a===b)
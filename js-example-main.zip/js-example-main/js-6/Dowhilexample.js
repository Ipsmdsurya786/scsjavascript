let i=1;
do
{
    console.log('hello')
    i++;
}while(i>10)